import * as ton from './ton';
import * as tron from './tron';

export default {
  ton,
  tron,
};
