export const ONE_TRX = 1_000_000n;
