export const SEC = 1000;
export const FIRST_TRANSACTIONS_LIMIT = 50;
