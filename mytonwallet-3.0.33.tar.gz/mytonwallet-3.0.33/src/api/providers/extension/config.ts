export const POPUP_PORT = 'MyTonWallet_popup';
export const CONTENT_SCRIPT_PORT = 'MyTonWallet_contentScript';
export const PAGE_CONNECTOR_CHANNEL = 'MyTonWallet_pageConnector';
